
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("questionnaireForm");
    const formSteps = Array.from(form.querySelectorAll(".form-step"));
    const nextButtons = form.querySelectorAll(".next-step");
    const prevButtons = form.querySelectorAll(".prev-step");
    const sexSelect = document.getElementById("sex");
    const periodsQuestion = document.getElementById("periods-question");
    const periodsSelect = document.getElementById("periods");

    let currentStep = 0;

    // Function to show a specific step
    function showStep(stepIndex) {
        formSteps.forEach((step, index) => {
            step.style.display = index === stepIndex ? "block" : "none";
        });
        currentStep = stepIndex;
    }

    // Initial display
    showStep(currentStep);

    // Event listener for sex selection to show/hide periods question
    if (sexSelect && periodsQuestion) {
        sexSelect.addEventListener("change", function() {
            if (sexSelect.value === "female") {
                periodsQuestion.style.display = "block";
                periodsSelect.setAttribute("required", "required");
            } else {
                periodsQuestion.style.display = "none";
                periodsSelect.removeAttribute("required");
            }
        });
        // Trigger change on load if value is already set (e.g., from session data)
        if (sexSelect.value === "female") {
            periodsQuestion.style.display = "block";
            periodsSelect.setAttribute("required", "required");
        }
    }

    // Client-side validation for each step
    function validateStep(stepIndex) {
        const currentFormStep = formSteps[stepIndex];
        const inputs = currentFormStep.querySelectorAll("input[required], select[required], textarea[required]");
        let isValid = true;

        inputs.forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                input.classList.add("is-invalid");
            } else {
                input.classList.remove("is-invalid");
            }

            // Specific validation for number inputs
            if (input.type === "number") {
                const min = parseFloat(input.min);
                const max = parseFloat(input.max);
                const value = parseFloat(input.value);
                if (isNaN(value) || value < min || value > max) {
                    isValid = false;
                    input.classList.add("is-invalid");
                }
            }

            // Specific validation for date input
            if (input.type === "date") {
                const dob = new Date(input.value);
                const today = new Date();
                if (dob > today) {
                    isValid = false;
                    input.classList.add("is-invalid");
                }
            }
        });

        // Radio button validation (for water intake)
        const waterIntakeRadios = currentFormStep.querySelectorAll("input[name=\"water_intake\"]");
        if (waterIntakeRadios.length > 0) {
            let radioChecked = false;
            waterIntakeRadios.forEach(radio => {
                if (radio.checked) {
                    radioChecked = true;
                }
            });
            if (!radioChecked) {
                isValid = false;
                // Optionally, add a visual cue for the user
                waterIntakeRadios[0].closest(".form-group").classList.add("is-invalid");
            } else {
                waterIntakeRadios[0].closest(".form-group").classList.remove("is-invalid");
            }
        }

        return isValid;
    }

    // Handle next step button clicks
    nextButtons.forEach(button => {
        button.addEventListener("click", function() {
            if (validateStep(currentStep)) {
                // Send current step data to backend to save in session
                const currentFormStep = formSteps[currentStep];
                const formData = new FormData(form);
                const stepData = {};
                currentFormStep.querySelectorAll("input, select, textarea").forEach(input => {
                    if (input.name) {
                        if (input.type === "radio" && !input.checked) {
                            return; // Skip unchecked radios
                        }
                        stepData[input.name] = input.value;
                    }
                });

                fetch(form.action, {
                    method: "POST",
                    body: new URLSearchParams(stepData),
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showStep(currentStep + 1);
                    } else {
                        alert("Error saving data: " + data.message);
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while saving your data.");
                });
            }
        });
    });

    // Handle previous step button clicks
    prevButtons.forEach(button => {
        button.addEventListener("click", function() {
            showStep(currentStep - 1);
        });
    });

    // Handle final form submission
    form.addEventListener("submit", function(event) {
        if (!validateStep(formSteps.length - 1)) {
            event.preventDefault(); // Prevent submission if last step is invalid
            alert("Please fill in all required fields in the last step.");
        }
        // If valid, the form will submit normally to the backend
    });

    // Populate form fields from session data on load
    const questionnaireData = {{ questionnaire_data | tojson }};
    for (const key in questionnaireData) {
        const input = form.querySelector(`[name="${key}"]`);
        if (input) {
            if (input.type === "radio") {
                form.querySelector(`input[name="${key}"][value="${questionnaireData[key]}"]`).checked = true;
            } else {
                input.value = questionnaireData[key];
            }
        }
    }

    // Re-evaluate periods question visibility after populating data
    if (sexSelect && periodsQuestion && sexSelect.value === "female") {
        periodsQuestion.style.display = "block";
        periodsSelect.setAttribute("required", "required");
    }
});


