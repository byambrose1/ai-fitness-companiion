
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import os
import bcrypt
import openai
from datetime import datetime
import json
import sqlite3
import re
from database import get_user, save_user, add_daily_log, get_user_logs, add_weekly_checkin, get_user_checkins
from email_service import email_service
from security_monitoring import SecurityMonitor
import stripe

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-key-change-in-production")

# OpenAI setup
openai.api_key = os.getenv("OPENAI_API_KEY", "")

# Stripe setup
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

# Initialize security monitoring
security_monitor = SecurityMonitor()

# Track number of signups - in a real app, this would be in a database
import threading
signup_count = 0
signup_lock = threading.Lock()

def validate_email(email):
    """Validate email format and check if it's a real email domain"""
    # Basic email regex
    email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    if not re.match(email_pattern, email):
        return False

    # Check for common fake email domains
    fake_domains = ["fake.com", "example.com", "test.com", "invalid.com", "temp.com"]
    domain = email.split("@")[1].lower()
    if domain in fake_domains:
        return False

    # Additional validation could include DNS lookup for domain
    return True

def generate_personalized_insights(profile_data, recent_logs):
    """Generate personalized insights based on questionnaire data and recent log patterns"""
    goal = profile_data.get("goal", "fat_loss")
    activity_level = profile_data.get("activity_level", "") or ""
    dietary_preferences = profile_data.get("dietary_preferences", "") or ""
    health_conditions = (profile_data.get("health_conditions") or "").lower()
    
    insights = {
        "main_message": "",
        "focus_areas": [],
        "specific_tips": [],
        "habit_suggestions": []
    }
    
    # Analyze recent patterns if logs exist
    if recent_logs:
        # Water intake analysis
        water_logs = [log.get("water_intake") for log in recent_logs if log.get("water_intake")]
        poor_water_days = len([w for w in water_logs if w in ["low", "moderate"]])
        
        if poor_water_days >= len(water_logs) * 0.6:  # 60% or more poor water days
            insights["focus_areas"].append({
                "area": "Hydration",
                "icon": "💧",
                "message": "You've reported low water intake consistently - aim for 2L today.",
                "tip": "Start your day with a large glass of water and keep a bottle nearby as a visual reminder."
            })
        
        # Sleep analysis
        sleep_logs = [float(log.get("sleep_hours", 0)) for log in recent_logs if log.get("sleep_hours") and str(log.get("sleep_hours")).replace(".", "").isdigit()]
        if sleep_logs:
            avg_sleep = sum(sleep_logs) / len(sleep_logs)
            if avg_sleep < 6.5:
                insights["focus_areas"].append({
                    "area": "Sleep Quality",
                    "icon": "😴",
                    "message": f"Your average sleep is {avg_sleep:.1f}h - this affects fat loss hormones.",
                    "tip": "Poor sleep increases hunger hormones. Try going to bed 30 minutes earlier tonight."
                })
        
        # Food pattern analysis
        food_logs = [log.get("food_log", "").lower() for log in recent_logs if log.get("food_log")]
        takeaway_mentions = len([f for f in food_logs if any(word in f for word in ["takeaway", "pizza", "mcdonald", "delivery", "chips"])])
        protein_mentions = len([f for f in food_logs if any(word in f for word in ["chicken", "fish", "protein", "eggs", "yogurt", "beans"])])
        
        if takeaway_mentions >= len(food_logs) * 0.4:  # 40% or more takeaway days
            insights["focus_areas"].append({
                "area": "Food Choices",
                "icon": "🥗",
                "message": "Multiple takeaway meals this week - let's focus on home cooking.",
                "tip": "Prep 2-3 simple meals this weekend. Even basic options beat takeaway for fat loss."
            })
        elif protein_mentions < len(food_logs) * 0.3:  # Less than 30% protein mentions
            insights["focus_areas"].append({
                "area": "Protein Intake",
                "icon": "🍗",
                "message": "Protein intake seems low - this is crucial for fat loss and staying full.",
                "tip": "Add protein to every meal: eggs at breakfast, chicken/fish at lunch, Greek yogurt as snacks."
            })
        
        # Stress analysis
        stress_logs = [int(log.get("stress_level", 5)) for log in recent_logs if log.get("stress_level") and str(log.get("stress_level")).isdigit()]
        if stress_logs and sum(stress_logs) / len(stress_logs) >= 7:
            insights["focus_areas"].append({
                "area": "Stress Management",
                "icon": "🧘‍♀️",
                "message": "High stress levels can trigger cortisol and emotional eating.",
                "tip": "Try 5 minutes of deep breathing before meals to activate your calm response."
            })
        
        # Workout consistency
        workouts = [log.get("workout", "rest") for log in recent_logs if log.get("workout")]
        workout_days = len([w for w in workouts if w != "rest"])
        if workout_days < 2 and activity_level in ["sedentary", "lightly_active"]:
            insights["focus_areas"].append({
                "area": "Movement",
                "icon": "🚶‍♀️",
                "message": "More movement will boost your metabolism and mood.",
                "tip": "Start with 15-minute walks after meals. This aids digestion and fat burning."
            })
    
    # Activity level-specific insights
    if activity_level == "sedentary":
        insights["habit_suggestions"].append({
            "habit": "Start with micro-movements",
            "description": "Set hourly reminders to stand and stretch for 2 minutes"
        })
    elif activity_level == "lightly_active":
        insights["habit_suggestions"].append({
            "habit": "Build movement consistency",
            "description": "Aim for 20-30 minutes of activity 4 days this week"
        })
    
    # Dietary preference insights
    if dietary_preferences == "vegetarian":
        insights["specific_tips"].append("Focus on plant proteins: lentils, quinoa, Greek yogurt, and eggs for fat loss.")
    elif dietary_preferences == "keto":
        insights["specific_tips"].append("Track your healthy fats and ensure you're in a calorie deficit for fat loss.")
    
    # Health condition considerations
    if "stress" in health_conditions or "anxiety" in health_conditions:
        insights["specific_tips"].append("Manage stress first - high cortisol makes fat loss much harder.")
    if "sleep" in health_conditions or "insomnia" in health_conditions:
        insights["specific_tips"].append("Prioritize sleep hygiene - poor sleep disrupts hunger hormones.")
    
    # Generate main contextual message
    if insights["focus_areas"]:
        main_focus = insights["focus_areas"][0]
        insights["main_message"] = f'Your biggest opportunity: {main_focus["message"]} 🎯'
    else:
        if recent_logs:
            insights["main_message"] = "You're tracking consistently - that's the foundation of lasting fat loss! 🌟"
        else:
            insights["main_message"] = "Ready to start your fat loss journey? Your first log will unlock personalized insights! 🚀"
    
    return insights

def calculate_personalised_daily_score(log_data, profile_data):
    """Calculate a personalised daily score based on user's goals and questionnaire responses"""
    goal = profile_data.get("goal", "general_fitness")
    activity_level = profile_data.get("activity_level", "moderately_active") or "moderately_active"
    dietary_preferences = profile_data.get("dietary_preferences", "none") or "none"
    health_conditions = profile_data.get("health_conditions", "") or ""
    
    score = 3  # Base score
    insights = []
    
    # Goal-specific scoring weights
    goal_weights = {
        "weight_loss": {"workout": 2.5, "food": 2.0, "water": 1.5, "sleep": 1.5, "mood": 1.0},
        "muscle_gain": {"workout": 3.0, "food": 2.5, "sleep": 2.0, "water": 1.0, "mood": 1.0},
        "general_fitness": {"workout": 2.0, "mood": 2.0, "sleep": 1.5, "water": 1.5, "food": 1.5},
        "endurance": {"workout": 3.0, "water": 2.0, "sleep": 2.0, "food": 1.5, "mood": 1.0},
        "strength": {"workout": 3.0, "food": 2.0, "sleep": 2.0, "water": 1.0, "mood": 1.0}
    }
    
    weights = goal_weights.get(goal, goal_weights["general_fitness"])
    
    # Mood scoring with goal context
    if log_data.get("mood"):
        mood_score = {"excellent": 1.0, "good": 0.8, "okay": 0.5, "low": 0.2}.get(log_data["mood"], 0)
        score += mood_score * weights["mood"]
        
        if log_data["mood"] in ["excellent", "good"]:
            if goal == "weight_loss":
                insights.append("🧠 Great mood supports healthy choices! You're more likely to stick to your weight loss plan when feeling positive.")
            elif goal == "muscle_gain":
                insights.append("💪 Positive mindset enhances workout performance and muscle growth!")
            else:
                insights.append("😊 Excellent mood creates the perfect foundation for healthy habits!")
        elif log_data["mood"] == "low":
            insights.append("💚 Tough days happen - the fact you're still tracking shows real commitment. Tomorrow is a fresh start.")
    
    # Workout scoring with goal and activity level context
    if log_data.get("workout"):
        workout_type = log_data["workout"]
        if workout_type != "rest":
            base_workout_score = 1.0
            
            # Adjust based on activity level expectations
            if activity_level in ["very_active", "extremely_active"] and workout_type in ["cardio", "strength"]:
                base_workout_score = 1.2  # Higher expectations
            elif activity_level == "sedentary" and workout_type in ["walking", "yoga"]:
                base_workout_score = 1.5  # Celebrate any movement
                
            score += base_workout_score * weights["workout"]
            
            # Goal-specific workout insights
            if goal == "weight_loss":
                if workout_type == "cardio":
                    insights.append("🔥 Cardio is brilliant for weight loss! You're burning calories and improving your cardiovascular health.")
                elif workout_type == "strength":
                    insights.append("💪 Strength training builds muscle, which burns more calories at rest - perfect for weight loss!")
                else:
                    insights.append("🏃‍♀️ Every bit of movement counts towards your weight loss journey!")
            elif goal == "muscle_gain":
                if workout_type == "strength":
                    insights.append("🏋️‍♀️ Strength training is the foundation of muscle building - you're on the right track!")
                elif workout_type == "cardio":
                    insights.append("❤️ Light cardio supports recovery and muscle growth when balanced with strength training.")
            elif goal == "endurance":
                if workout_type == "cardio":
                    insights.append("🏃‍♀️ Building that cardiovascular endurance - each session makes you stronger!")
                    
        elif workout_type == "rest":
            score += 0.5 * weights["workout"]
            if activity_level in ["very_active", "extremely_active"]:
                insights.append("😴 Rest days are crucial for recovery, especially with your high activity level!")
            else:
                insights.append("💤 Rest is part of the process - your body repairs and grows stronger during recovery.")
    
    # Water intake with activity level context
    if log_data.get("water_intake"):
        water_score = {"excellent": 1.0, "good": 0.8, "moderate": 0.5, "low": 0.2}.get(log_data["water_intake"], 0)
        score += water_score * weights["water"]
        
        if log_data["water_intake"] in ["excellent", "good"]:
            if goal == "weight_loss":
                insights.append("💧 Excellent hydration supports your metabolism and helps control hunger - key for weight loss!")
            elif activity_level in ["very_active", "extremely_active"]:
                insights.append("💦 Great hydration is essential for your high activity level - well done!")
            else:
                insights.append("💧 Proper hydration supports every function in your body - you're nailing it!")
    
    # Sleep scoring with goal context
    if log_data.get("sleep_hours"):
        try:
            sleep_hours = float(log_data["sleep_hours"])
            if 7 <= sleep_hours <= 9:
                sleep_score = 1.0
                if goal == "weight_loss":
                    insights.append("🌙 7-9 hours sleep is perfect for weight loss - it regulates hunger hormones and supports recovery!")
                elif goal == "muscle_gain":
                    insights.append("💤 Excellent sleep! This is when your muscles actually grow and repair - crucial for your goals.")
                else:
                    insights.append("😴 Perfect sleep duration! Your body and mind will thank you today.")
            elif 6 <= sleep_hours < 7:
                sleep_score = 0.7
                insights.append("⏰ Nearly there on sleep! Even 30 minutes more can boost energy and mood significantly.")
            elif sleep_hours < 6:
                sleep_score = 0.3
                if goal == "weight_loss":
                    insights.append("😴 Poor sleep affects hunger hormones - try to prioritise rest for better weight loss results.")
                else:
                    insights.append("💤 Your body needs more rest to perform at its best. Consider an earlier bedtime tonight.")
            else:  # > 9 hours
                sleep_score = 0.8
                insights.append("😴 Lots of sleep! If you're feeling refreshed, that's what matters most.")
                
            score += sleep_score * weights["sleep"]
        except ValueError:
            pass
    
    # Food scoring with dietary preferences context
    if log_data.get("food_log"):
        food_text = log_data["food_log"].lower()
        food_score = 0.5  # Base food logging score
        
        # Check for takeaway/processed foods
        takeaway_indicators = ["takeaway", "mcdonald", "kfc", "domino", "pizza", "delivery", "uber eats", "deliveroo"]
        has_takeaway = any(indicator in food_text for indicator in takeaway_indicators)
        
        if has_takeaway:
            if goal == "weight_loss":
                food_score = 0.3
                insights.append("🍕 Takeaway day! No judgement - balance is key. Try adding some extra vegetables or walking tomorrow.")
            else:
                food_score = 0.4
                insights.append("🍔 Takeaway happens! The important thing is getting back to your usual routine tomorrow.")
        else:
            # Check for healthy food indicators
            healthy_indicators = ["salad", "vegetables", "fruit", "chicken", "fish", "oats", "quinoa", "yogurt"]
            healthy_count = sum(1 for indicator in healthy_indicators if indicator in food_text)
            
            if healthy_count >= 2:
                food_score = 1.0
                if dietary_preferences == "vegetarian" and any(veg in food_text for veg in ["vegetables", "salad", "quinoa"]):
                    insights.append("🌱 Brilliant vegetarian choices! You're nourishing your body perfectly.")
                elif goal == "weight_loss":
                    insights.append("🥗 Fantastic food choices for weight loss! Whole foods will keep you satisfied and energised.")
                elif goal == "muscle_gain":
                    insights.append("🍗 Great protein and nutrient choices - perfect fuel for muscle building!")
                else:
                    insights.append("🌟 Wonderful food choices! You're giving your body quality fuel.")
            elif healthy_count == 1:
                food_score = 0.8
                insights.append("🥦 Good to see some healthy choices in there! Keep it up.")
            else:
                insights.append("🤔 Your food log is a bit of a mystery! Try to be more descriptive to get better insights.")

        score += food_score * weights["food"]

    # Final score adjustment
    final_score = min(10, max(0, round(score, 1)))
    
    return final_score, insights

def generate_ai_response(user_input, user_profile, chat_history):
    """Generate AI response using OpenAI based on user input, profile, and history"""
    # Construct a detailed prompt for the AI
    system_prompt = f"""You are a supportive and knowledgeable AI Fitness Companion. Your goal is to help the user achieve their fitness goals, primarily focusing on fat loss. You are empathetic, encouraging, and provide actionable advice. You are not a doctor; always remind users to consult a professional for medical advice.

    User Profile:
    - Goal: {user_profile.get('goal', 'Not specified')}
    - Activity Level: {user_profile.get('activity_level', 'Not specified')}
    - Dietary Preferences: {user_profile.get('dietary_preferences', 'Not specified')}
    - Health Conditions: {user_profile.get('health_conditions', 'None')}
    - Motivation: {user_profile.get('motivation', 'Not specified')}

    Your tone should be: friendly, positive, and non-judgemental. Use emojis to add warmth. Avoid overly complex jargon. Keep responses concise and easy to understand.
    """

    messages = [
        {"role": "system", "content": system_prompt}
    ]

    # Add chat history to the prompt
    for message in chat_history:
        messages.append(message)

    # Add the user's latest message
    messages.append({"role": "user", "content": user_input})

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=200,
            temperature=0.7
        )
        ai_message = response.choices[0].message["content"].strip()
        return ai_message
    except Exception as e:
        print(f"Error generating AI response: {e}")
        return "I'm having a little trouble connecting right now. Please try again in a moment."

@app.route("/signup", methods=["POST"])
def signup():
    global signup_count
    with signup_lock:
        signup_count += 1
        current_signup_count = signup_count

    # Basic rate limiting for signups
    if current_signup_count > 20:
        return jsonify({"error": "Signup limit reached for this period. Please try again later."}), 429

    data = request.get_json()
    full_name = data.get("fullName", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    dob_str = data.get("dob", "")

    # Validate inputs
    if not all([full_name, email, password, dob_str]):
        return jsonify({"error": "All fields are required."}), 400

    if not validate_email(email):
        return jsonify({"error": "Invalid or disposable email address."}), 400

    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters long."}), 400

    try:
        dob = datetime.strptime(dob_str, "%Y-%m-%d")
        if dob > datetime.now():
            return jsonify({"error": "Date of birth cannot be in the future."}), 400
    except ValueError:
        return jsonify({"error": "Invalid date of birth format. Use YYYY-MM-DD."}), 400

    # Check if user already exists
    if get_user(email):
        return jsonify({"error": "An account with this email already exists."}), 409

    # Hash the password
    hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())

    # Create new user
    new_user = {
        "email": email,
        "full_name": full_name,
        "password_hash": hashed_password.decode("utf-8"),
        "dob": dob_str,
        "profile_data": {},
        "chat_history": [],
        "daily_logs": [],
        "weekly_checkins": [],
        "created_at": datetime.utcnow().isoformat()
    }

    # Save user to the database
    save_user(new_user)

    # Store user in session
    session["user_email"] = email

    # Send welcome email
    try:
        email_service.send_welcome_email(email, full_name)
    except Exception as e:
        print(f"Failed to send welcome email: {e}")

    return jsonify({"message": "Account created successfully! Redirecting to questionnaire..."}), 201

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400

    user = get_user(email)
    if user and bcrypt.checkpw(password.encode("utf-8"), user["password_hash"].encode("utf-8")):
        session["user_email"] = email
        return jsonify({"message": "Login successful!"}), 200
    else:
        # Monitor for failed login attempts
        security_monitor.record_failed_login(email, request.remote_addr)
        if security_monitor.is_ip_blocked(request.remote_addr):
            return jsonify({"error": "Too many failed login attempts. Please try again later."}), 429
        return jsonify({"error": "Invalid credentials."}), 401

@app.route("/logout")
def logout():
    session.pop("user_email", None)
    return redirect(url_for("landing_page"))

@app.route("/dashboard")
def dashboard():
    if "user_email" not in session:
        return redirect(url_for("landing_page"))

    user = get_user(session["user_email"])
    if not user:
        return redirect(url_for("landing_page"))

    # Check if questionnaire is complete
    if not user.get("profile_data") or "goal" not in user.get("profile_data", {}):
        return redirect(url_for("questionnaire"))

    # Get recent logs for insights
    recent_logs = get_user_logs(session["user_email"], limit=7)
    insights = generate_personalized_insights(user.get("profile_data", {}), recent_logs)

    return render_template("dashboard.html", user=user, insights=insights)

@app.route("/log/daily", methods=["POST"])
def log_daily():
    if "user_email" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json()
    required_fields = ["mood", "sleep_hours", "water_intake", "stress_level", "workout", "food_log"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": "All fields are required for daily log."}), 400

    # Basic validation
    try:
        sleep_hours = float(data["sleep_hours"])
        if not (0 <= sleep_hours <= 24):
            return jsonify({"error": "Invalid sleep hours."}), 400
    except ValueError:
        return jsonify({"error": "Sleep hours must be a number."}), 400

    stress_level = int(data["stress_level"])
    if not (1 <= stress_level <= 10):
        return jsonify({"error": "Invalid stress level."}), 400

    log_entry = {
        "date": datetime.utcnow().strftime("%Y-%m-%d"),
        "mood": data["mood"],
        "sleep_hours": sleep_hours,
        "water_intake": data["water_intake"],
        "stress_level": stress_level,
        "workout": data["workout"],
        "food_log": data["food_log"].strip()
    }

    add_daily_log(session["user_email"], log_entry)

    # Calculate score and get insights for the new log
    user = get_user(session["user_email"])
    score, insights = calculate_personalised_daily_score(log_entry, user.get("profile_data", {}))

    return jsonify({
        "message": "Daily log saved successfully!",
        "score": score,
        "insights": insights
    }), 201

@app.route("/checkin/weekly", methods=["POST"])
def checkin_weekly():
    if "user_email" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json()
    required_fields = ["current_weight", "progress_feeling", "challenges"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": "All fields are required for weekly check-in."}), 400

    try:
        current_weight = float(data["current_weight"])
        if not (20 <= current_weight <= 300):  # Basic weight range validation
            return jsonify({"error": "Invalid weight."}), 400
    except ValueError:
        return jsonify({"error": "Weight must be a number."}), 400

    checkin_entry = {
        "date": datetime.utcnow().strftime("%Y-%m-%d"),
        "current_weight": current_weight,
        "progress_feeling": data["progress_feeling"],
        "challenges": data["challenges"].strip()
    }

    add_weekly_checkin(session["user_email"], checkin_entry)
    return jsonify({"message": "Weekly check-in saved successfully!"}), 201

@app.route("/chat", methods=["POST"])
def chat():
    if "user_email" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    user_input = request.json.get("message", "").strip()
    if not user_input:
        return jsonify({"error": "Message cannot be empty."}), 400

    user = get_user(session["user_email"])
    if not user:
        return jsonify({"error": "User not found."}), 404

    # Get chat history and profile data
    chat_history = user.get("chat_history", [])
    profile_data = user.get("profile_data", {})

    # Add user message to history
    chat_history.append({"role": "user", "content": user_input})

    # Generate AI response
    ai_response = generate_ai_response(user_input, profile_data, chat_history)

    # Add AI response to history
    chat_history.append({"role": "assistant", "content": ai_response})

    # Update user's chat history
    user["chat_history"] = chat_history[-20:]  # Keep last 20 messages
    save_user(user)

    return jsonify({"response": ai_response})

@app.route("/settings", methods=["GET", "POST"])
def settings():
    if "user_email" not in session:
        return redirect(url_for("landing_page"))

    user = get_user(session["user_email"])
    if not user:
        return redirect(url_for("landing_page"))

    if request.method == "POST":
        # Update user settings
        user["full_name"] = request.form.get("fullName", user["full_name"])
        
        # Password update
        current_password = request.form.get("currentPassword")
        new_password = request.form.get("newPassword")
        if current_password and new_password:
            if bcrypt.checkpw(current_password.encode("utf-8"), user["password_hash"].encode("utf-8")):
                if len(new_password) < 8:
                    flash("New password must be at least 8 characters long.", "error")
                else:
                    user["password_hash"] = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
                    flash("Password updated successfully!", "success")
            else:
                flash("Incorrect current password.", "error")
        
        save_user(user)
        return redirect(url_for("settings"))

    return render_template("settings.html", user=user)

@app.route("/subscribe", methods=["POST"])
def subscribe():
    if "user_email" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price": "YOUR_STRIPE_PRICE_ID",  # Replace with your actual price ID
                    "quantity": 1,
                },
            ],
            mode="subscription",
            success_url=url_for("dashboard", _external=True) + "?payment=success",
            cancel_url=url_for("dashboard", _external=True) + "?payment=cancelled",
            customer_email=session["user_email"],
        )
        return jsonify({"id": checkout_session.id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/")
def landing_page():
    if "user_email" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")

@app.route("/admin/dashboard")
def admin_dashboard():
    # Simple admin check - in a real app, use proper roles
    if session.get("user_email") != "admin@yourapp.com":
        return "Unauthorized", 401
    
    # In a real app, you would fetch all users from the database
    # For this example, we'll just show the signup count
    return f"<h1>Admin Dashboard</h1><p>Total Signups: {signup_count}</p>"


# Error handling for 404
@app.errorhandler(404)
def not_found_error(error):
    return render_template("404.html"), 404

# Error handling for 500
@app.errorhandler(500)
def internal_error(error):
    return render
@app.route("/questionnaire", methods=["GET", "POST"])
def questionnaire():
    if "user_email" not in session:
        return redirect(url_for("landing_page"))

    user = get_user(session["user_email"])
    if not user:
        return redirect(url_for("landing_page"))

    if request.method == "POST":
        if "questionnaire_data" not in session:
            session["questionnaire_data"] = {}

        session["questionnaire_data"].update(request.form.to_dict())
        session.modified = True

        # Check if it's the final step of the questionnaire
        if 'stress_level' in request.form:
            profile_data = user.get("profile_data", {})
            profile_data.update(session["questionnaire_data"])
            user["profile_data"] = profile_data
            save_user(user)
            session.pop("questionnaire_data", None)
            return jsonify(success=True, redirect_url=url_for("dashboard"))

        return jsonify(success=True)

    return render_template("questionnaire.html", questionnaire_data=session.get("questionnaire_data", {}))
e("questionnaire.html", questionnaire_data=questionnaire_data)

if __name__ == "__main__":
    # Ensure the database is initialized before running the app
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            full_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            dob TEXT NOT NULL,
            profile_data TEXT,
            chat_history TEXT,
            daily_logs TEXT,
            weekly_checkins TEXT,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()
    print("Database initialized successfully")
    app.run(debug=True, host="0.0.0.0", port=5000)


